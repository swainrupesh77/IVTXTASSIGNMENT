const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

// POST /api/orders — place a new order
router.post('/', async (req, res) => {
  try {
    const { customer, burger } = req.body;

    // Basic validation
    if (!customer?.name || !customer?.mobile || !customer?.address || !customer?.payment) {
      return res.status(400).json({ error: 'All customer fields are required.' });
    }
    if (!/^\d{10}$/.test(customer.mobile)) {
      return res.status(400).json({ error: 'Mobile must be 10 digits.' });
    }
    if (!burger?.slices?.length || !burger?.quantity || !burger?.totalPrice) {
      return res.status(400).json({ error: 'Invalid burger configuration.' });
    }

    const order = new Order({ customer, burger });
    const saved = await order.save();
    res.status(201).json({ message: 'Order placed successfully!', order: saved });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// GET /api/orders — get all orders
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
