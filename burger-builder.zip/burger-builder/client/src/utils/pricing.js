import { SLICE_MAP, PLATFORM_FEE } from '../constants';

export function calcPrice(stack, qty) {
  const midSlices = stack.slice(1, -1); // exclude bread layers

  let base = 0;
  midSlices.forEach((id) => {
    const s = SLICE_MAP[id];
    if (s) base += s.price;
  });

  // Conditional pricing rules
  let discount = 0;
  let extra = 0;

  const hasCheese = midSlices.includes('cheese');
  const hasPaneer = midSlices.includes('paneer');
  if (hasCheese && hasPaneer) discount = 3;

  for (let i = 0; i < midSlices.length - 1; i++) {
    if (midSlices[i] === 'alootikki' && midSlices[i + 1] === 'alootikki') {
      extra += 2;
    }
  }

  const perBurger = base - discount + extra;
  const total = perBurger * qty + PLATFORM_FEE;

  return { base, discount, extra, perBurger, total };
}
