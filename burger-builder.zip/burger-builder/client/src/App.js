import React from 'react';
import { BurgerProvider } from './context/BurgerContext';
import Builder from './pages/Builder';
import './index.css';

export default function App() {
  return (
    <BurgerProvider>
      <div className="app-shell">
        <header className="app-header">
          <span className="logo">🍔</span>
          <h1>Burger Builder</h1>
        </header>
        <main className="app-main">
          <Builder />
        </main>
      </div>
    </BurgerProvider>
  );
}
