import React, { useState } from 'react';
import BurgerVisualization from '../components/BurgerVisualization';
import SliceSelector from '../components/SliceSelector';
import PriceSummary from '../components/PriceSummary';
import CheckoutForm from '../components/CheckoutForm';

export default function Builder() {
  const [view, setView] = useState('build'); // 'build' | 'checkout' | 'success'
  const [customerName, setCustomerName] = useState('');

  function handleSuccess(name) {
    setCustomerName(name);
    setView('success');
  }

  if (view === 'success') {
    return (
      <div className="success-screen">
        <div className="success-box">
          <div className="success-icon">✓</div>
          <h2>Order Placed!</h2>
          <p>Thank you, <strong>{customerName}</strong>! Your burger is being prepared.</p>
          <button
            className="btn btn-place"
            onClick={() => setView('build')}
          >
            Build Another Burger
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="builder-page">
      <div className="builder-left">
        <BurgerVisualization />
        <PriceSummary />
      </div>

      <div className="builder-right">
        {view === 'build' ? (
          <>
            <SliceSelector />
            <button
              className="btn btn-place"
              style={{ marginTop: '1rem', width: '100%' }}
              onClick={() => setView('checkout')}
            >
              Proceed to Checkout →
            </button>
          </>
        ) : (
          <>
            <CheckoutForm onSuccess={handleSuccess} />
            <button
              className="btn btn-back"
              onClick={() => setView('build')}
            >
              ← Back to Builder
            </button>
          </>
        )}
      </div>
    </div>
  );
}
