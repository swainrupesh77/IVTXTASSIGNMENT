import React, { createContext, useContext, useReducer } from 'react';
import { MAX_SLICES } from '../constants';

const BurgerContext = createContext();

const initialState = {
  stack: ['bread', 'bread'], // bread is always first and last
  qty: 1,
};

function reducer(state, action) {
  switch (action.type) {
    case 'ADD_SLICE': {
      const mid = state.stack.slice(1, -1);
      if (mid.length >= MAX_SLICES - 2) return state; // max 8 fillings
      return {
        ...state,
        stack: [state.stack[0], ...mid, action.id, state.stack[state.stack.length - 1]],
      };
    }
    case 'REMOVE_SLICE': {
      const idx = action.idx;
      if (idx === 0 || idx === state.stack.length - 1) return state;
      return { ...state, stack: state.stack.filter((_, i) => i !== idx) };
    }
    case 'MOVE_UP': {
      const idx = action.idx;
      if (idx <= 1) return state;
      const s = [...state.stack];
      [s[idx], s[idx - 1]] = [s[idx - 1], s[idx]];
      return { ...state, stack: s };
    }
    case 'MOVE_DOWN': {
      const idx = action.idx;
      if (idx >= state.stack.length - 2) return state;
      const s = [...state.stack];
      [s[idx], s[idx + 1]] = [s[idx + 1], s[idx]];
      return { ...state, stack: s };
    }
    case 'SET_QTY':
      return { ...state, qty: Math.max(1, action.qty) };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

export function BurgerProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <BurgerContext.Provider value={{ state, dispatch }}>
      {children}
    </BurgerContext.Provider>
  );
}

export function useBurger() {
  return useContext(BurgerContext);
}
