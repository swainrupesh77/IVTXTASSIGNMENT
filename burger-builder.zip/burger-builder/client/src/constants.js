export const SLICES = [
  { id: 'alootikki', name: 'Aloo Tikki', price: 20, color: '#D85A30' },
  { id: 'paneer',    name: 'Paneer',     price: 25, color: '#534AB7' },
  { id: 'cheese',    name: 'Cheese',     price: 15, color: '#BA7517' },
  { id: 'tomato',    name: 'Tomato',     price: 10, color: '#D4537E' },
  { id: 'onion',     name: 'Onion',      price: 10, color: '#993C1D' },
  { id: 'lettuce',   name: 'Lettuce',    price:  8, color: '#3B6D11' },
];

export const PLATFORM_FEE = 10;
export const MAX_SLICES = 10; // including 2 bread layers = 8 fillings max

export const SLICE_MAP = Object.fromEntries(SLICES.map((s) => [s.id, s]));
