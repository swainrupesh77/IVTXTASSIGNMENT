import React from 'react';
import { useBurger } from '../context/BurgerContext';
import { calcPrice } from '../utils/pricing';

export default function PriceSummary() {
  const { state, dispatch } = useBurger();
  const { stack, qty } = state;
  const { base, discount, extra, perBurger, total } = calcPrice(stack, qty);

  return (
    <div className="price-summary">
      <h3>Price Breakdown</h3>

      <div className="price-rows">
        <div className="price-row">
          <span>Slices total</span>
          <span>₹{base}</span>
        </div>
        {discount > 0 && (
          <div className="price-row discount">
            <span>🧀 Cheese + Paneer discount</span>
            <span>-₹{discount}</span>
          </div>
        )}
        {extra > 0 && (
          <div className="price-row extra">
            <span>🔥 Consecutive Aloo Tikki charge</span>
            <span>+₹{extra}</span>
          </div>
        )}
        <div className="price-row">
          <span>Per burger</span>
          <span>₹{perBurger}</span>
        </div>

        <div className="qty-row">
          <span>Quantity</span>
          <div className="qty-ctrl">
            <button
              className="qty-btn"
              onClick={() => dispatch({ type: 'SET_QTY', qty: qty - 1 })}
            >−</button>
            <span className="qty-num">{qty}</span>
            <button
              className="qty-btn"
              onClick={() => dispatch({ type: 'SET_QTY', qty: qty + 1 })}
            >+</button>
          </div>
        </div>

        <div className="price-row">
          <span>Platform fee</span>
          <span>₹10</span>
        </div>
      </div>

      <div className="price-total">
        <span>Total</span>
        <span>₹{total}</span>
      </div>
    </div>
  );
}
