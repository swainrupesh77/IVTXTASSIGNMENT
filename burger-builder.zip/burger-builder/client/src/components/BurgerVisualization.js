import React from 'react';
import { useBurger } from '../context/BurgerContext';
import { SLICE_MAP } from '../constants';

const BREAD_COLOR = '#888780';

export default function BurgerVisualization() {
  const { state, dispatch } = useBurger();
  const { stack } = state;
  const midCount = stack.length - 2;

  return (
    <div className="burger-viz-wrapper">
      <h3>Burger Preview</h3>
      {midCount === 0 && (
        <p className="empty-hint">Add slices between the bread layers</p>
      )}
      <div className="burger-viz">
        {stack.map((id, i) => {
          const isBread = id === 'bread';
          const slice = isBread ? null : SLICE_MAP[id];
          const color = isBread ? BREAD_COLOR : slice?.color || '#999';
          const label = isBread ? 'Bread' : slice?.name || id;
          const widthPct = isBread ? 85 : Math.min(78, 42 + midCount * 4);
          const isFirst = i === 0;
          const isLast = i === stack.length - 1;

          return (
            <div key={i} className="slice-row">
              <span className="slice-row-label">{label}</span>
              <div
                className="slice-bar"
                style={{ width: `${widthPct}%`, background: color }}
              >
                {label}
              </div>
              {!isBread && (
                <div className="slice-controls">
                  <button
                    className="ctrl-btn"
                    onClick={() => dispatch({ type: 'MOVE_UP', idx: i })}
                    disabled={i <= 1}
                    title="Move up"
                  >↑</button>
                  <button
                    className="ctrl-btn"
                    onClick={() => dispatch({ type: 'MOVE_DOWN', idx: i })}
                    disabled={i >= stack.length - 2}
                    title="Move down"
                  >↓</button>
                  <button
                    className="ctrl-btn remove"
                    onClick={() => dispatch({ type: 'REMOVE_SLICE', idx: i })}
                    title="Remove"
                  >✕</button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {midCount > 6 && (
        <div className="chef-warn">
          Chef suggests splitting this burger into two burgers
        </div>
      )}
    </div>
  );
}
