import React from 'react';
import { SLICES, MAX_SLICES } from '../constants';
import { useBurger } from '../context/BurgerContext';

export default function SliceSelector() {
  const { state, dispatch } = useBurger();
  const fillingCount = state.stack.length - 2;
  const maxFillings = MAX_SLICES - 2;

  return (
    <div className="slice-selector">
      <h3>Add Slices</h3>
      <p className="hint">
        {fillingCount}/{maxFillings} filling slots used
      </p>
      <div className="slice-list">
        {SLICES.map((slice) => (
          <div key={slice.id} className="slice-item">
            <div className="slice-info">
              <span className="slice-dot" style={{ background: slice.color }} />
              <span className="slice-name">{slice.name}</span>
              <span className="slice-price">₹{slice.price}</span>
            </div>
            <button
              className="btn btn-add"
              onClick={() => dispatch({ type: 'ADD_SLICE', id: slice.id })}
              disabled={fillingCount >= maxFillings}
            >
              + Add
            </button>
          </div>
        ))}
      </div>
      {fillingCount >= maxFillings && (
        <div className="max-warn">Maximum slices reached (10 total)</div>
      )}
    </div>
  );
}
