import React, { useState } from 'react';
import axios from 'axios';
import { useBurger } from '../context/BurgerContext';
import { calcPrice } from '../utils/pricing';
import { SLICE_MAP } from '../constants';

export default function CheckoutForm({ onSuccess }) {
  const { state, dispatch } = useBurger();
  const { stack, qty } = state;
  const { total } = calcPrice(stack, qty);

  const [form, setForm] = useState({
    name: '', mobile: '', address: '', payment: '',
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');

  const midSlices = stack.slice(1, -1);

  function validate() {
    const e = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!/^\d{10}$/.test(form.mobile)) e.mobile = 'Enter a valid 10-digit mobile number';
    if (!form.address.trim()) e.address = 'Address is required';
    if (!form.payment) e.payment = 'Please select a payment method';
    return e;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setLoading(true);
    setApiError('');
    try {
      await axios.post('/api/orders', {
        customer: form,
        burger: { slices: midSlices, quantity: qty, totalPrice: total },
      });
      dispatch({ type: 'RESET' });
      onSuccess(form.name);
    } catch (err) {
      setApiError(err.response?.data?.error || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setErrors((er) => ({ ...er, [e.target.name]: '' }));
  }

  return (
    <form className="checkout-form" onSubmit={handleSubmit} noValidate>
      <h3>Checkout</h3>

      {/* Cart Summary */}
      <div className="cart-summary">
        <div className="cart-row"><span>Slice stack</span><span>{midSlices.map(id => SLICE_MAP[id]?.name).join(', ') || 'Empty'}</span></div>
        <div className="cart-row"><span>Quantity</span><span>{qty}</span></div>
        <div className="cart-row total"><span>Total</span><span>₹{total}</span></div>
      </div>

      <div className="form-grid">
        <div className="form-group">
          <label>Customer Name</label>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Full name"
          />
          {errors.name && <span className="err">{errors.name}</span>}
        </div>

        <div className="form-group">
          <label>Mobile Number</label>
          <input
            type="tel"
            name="mobile"
            value={form.mobile}
            onChange={handleChange}
            placeholder="10-digit number"
            maxLength={10}
          />
          {errors.mobile && <span className="err">{errors.mobile}</span>}
        </div>

        <div className="form-group full">
          <label>Delivery Address</label>
          <input
            type="text"
            name="address"
            value={form.address}
            onChange={handleChange}
            placeholder="House no, street, city"
          />
          {errors.address && <span className="err">{errors.address}</span>}
        </div>

        <div className="form-group">
          <label>Payment Method</label>
          <select name="payment" value={form.payment} onChange={handleChange}>
            <option value="">Select payment</option>
            <option value="upi">UPI</option>
            <option value="cash">Cash</option>
            <option value="cod">Cash on Delivery (COD)</option>
            <option value="netbanking">Net Banking</option>
          </select>
          {errors.payment && <span className="err">{errors.payment}</span>}
        </div>
      </div>

      {apiError && <div className="api-error">{apiError}</div>}

      <button type="submit" className="btn btn-place" disabled={loading}>
        {loading ? 'Placing Order...' : `Place Order — ₹${total}`}
      </button>
    </form>
  );
}
